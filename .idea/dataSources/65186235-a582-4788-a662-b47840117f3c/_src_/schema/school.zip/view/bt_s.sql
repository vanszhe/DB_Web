CREATE VIEW bt_s AS
  SELECT
    `school`.`student`.`Sno`           AS `Sno`,
    `school`.`student`.`Sname`         AS `Sname`,
    (2017 - `school`.`student`.`Sage`) AS `Syob`
  FROM `school`.`student`;
